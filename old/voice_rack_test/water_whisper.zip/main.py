import yaml
import numpy as np

from lamah.lamah_loader import load_lamah_column
from preprocess.normalize import percentile_normalize, log_normalize
from preprocess.threshold import apply_threshold
from scheduling.scheduler import generate_events

def run():
    cfg = yaml.safe_load(open("configs/channels.yaml"))

    all_events = []
    dt = cfg["time_step_seconds"]

    for name, ch in cfg["channels"].items():
        raw = next(load_lamah_column(ch["csv_path"], ch["column"]))

        if ch["scaling"] == "percentile":
            u = percentile_normalize(raw)
        else:
            u = log_normalize(raw)

        active = apply_threshold(raw, ch["threshold"])
        events = generate_events(u, active, dt, ch)
        all_events.append(events)

    events = np.concatenate(all_events, axis=0)
    np.save("events.npy", events)

if __name__ == "__main__":
    run()
