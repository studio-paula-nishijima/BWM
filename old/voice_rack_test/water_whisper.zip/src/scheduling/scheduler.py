import numpy as np

def compute_frequency(u, f_min, f_max, mode="linear"):
    if mode == "linear":
        return f_min + u * (f_max - f_min)
    elif mode == "log":
        return f_min * (f_max / f_min) ** u
    else:
        raise ValueError("mode")

def generate_events(values, active_mask, dt, config):
    f_min = config["freq_min"]
    f_max = config["freq_max"]
    t_on = config["t_on"]
    mode = config["scaling"]

    events = []
    phase = 0.0
    t = 0.0

    for i in range(len(values)):
        if not active_mask[i]:
            phase = 0.0
            t += dt
            continue

        u = values[i]
        f = compute_frequency(u, f_min, f_max, mode)

        phase += f * dt

        if phase >= 1.0:
            events.append((t, "pulse", t_on))
            phase -= 1.0

        t += dt

    return np.array(events, dtype=object)
