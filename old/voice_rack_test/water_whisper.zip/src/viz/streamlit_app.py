import streamlit as st
import plotly.graph_objects as go
import numpy as np
from diagnostics.density import compute_event_density, burst_statistics

def render(events):
    st.title("Water Whisper Diagnostics")

    times = np.array([e[0] for e in events])

    fig = go.Figure()
    fig.add_trace(go.Scatter(x=times, y=np.ones_like(times), mode="markers"))
    st.plotly_chart(fig)

    bins, density = compute_event_density(events)

    fig2 = go.Figure()
    fig2.add_trace(go.Scatter(x=bins, y=density))
    st.plotly_chart(fig2)

    st.json(burst_statistics(events))
